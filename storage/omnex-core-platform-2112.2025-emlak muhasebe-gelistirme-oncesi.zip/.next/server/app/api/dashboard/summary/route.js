var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/summary/route.js")
R.c("server/chunks/[root-of-the-server]__72a99e68._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_e1c7c61e.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_summary_route_actions_82d4c24f.js")
R.m(205583)
module.exports=R.m(205583).exports
