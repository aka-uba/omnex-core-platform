var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/core-ai/quota/route.js")
R.c("server/chunks/[root-of-the-server]__5ea509a0._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_core-ai_quota_route_actions_98fc70d9.js")
R.m(42562)
module.exports=R.m(42562).exports
