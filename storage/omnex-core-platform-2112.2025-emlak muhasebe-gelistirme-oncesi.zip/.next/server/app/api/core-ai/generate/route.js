var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/core-ai/generate/route.js")
R.c("server/chunks/[root-of-the-server]__b21df842._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_core-ai_generate_route_actions_7c2ffddc.js")
R.m(220146)
module.exports=R.m(220146).exports
