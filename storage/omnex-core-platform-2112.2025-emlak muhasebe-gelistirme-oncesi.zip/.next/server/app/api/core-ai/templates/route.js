var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/core-ai/templates/route.js")
R.c("server/chunks/[root-of-the-server]__a5e9100a._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_core-ai_templates_route_actions_de212e00.js")
R.m(657864)
module.exports=R.m(657864).exports
