var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/core-ai/templates/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__05dfe380._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_core-ai_templates_[id]_route_actions_b27a037f.js")
R.m(943550)
module.exports=R.m(943550).exports
