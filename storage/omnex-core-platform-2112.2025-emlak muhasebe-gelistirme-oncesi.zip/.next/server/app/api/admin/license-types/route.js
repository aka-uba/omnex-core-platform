var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/license-types/route.js")
R.c("server/chunks/[root-of-the-server]__5d60e919._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_core-client_fb52f6f0._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_license-types_route_actions_7eeb4ea3.js")
R.m(397181)
module.exports=R.m(397181).exports
