var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/license-notifications/check/route.js")
R.c("server/chunks/[root-of-the-server]__f8bd4ce2._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_core-client_fb52f6f0._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/ce889_server_app_api_admin_license-notifications_check_route_actions_dc67b00f.js")
R.m(842213)
module.exports=R.m(842213).exports
