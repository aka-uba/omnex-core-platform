var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/optimization/cache/list/route.js")
R.c("server/chunks/[root-of-the-server]__717146c5._.js")
R.c("server/chunks/node_modules_semver_fa4af7f7._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_86673fd6._.js")
R.c("server/chunks/ce889_server_app_api_admin_optimization_cache_list_route_actions_47754e7d.js")
R.m(933525)
module.exports=R.m(933525).exports
