var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/audit-logs/route.js")
R.c("server/chunks/[root-of-the-server]__bf2f5e61._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_audit-logs_route_actions_5e32e0b0.js")
R.m(759005)
module.exports=R.m(759005).exports
