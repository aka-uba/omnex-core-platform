var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/audit-logs/user/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__3bb1b242._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_audit-logs_user_[userId]_route_actions_ca3f2d06.js")
R.m(713852)
module.exports=R.m(713852).exports
