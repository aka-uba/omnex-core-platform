var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/audit-logs/entity/[entity]/[entityId]/route.js")
R.c("server/chunks/[root-of-the-server]__6e0bba0f._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/ce889_server_app_api_audit-logs_entity_[entity]_[entityId]_route_actions_15b8c819.js")
R.m(453886)
module.exports=R.m(453886).exports
