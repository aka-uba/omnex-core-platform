var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/calendar/events/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__3ccade40._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_calendar_events_[id]_route_actions_958f1c22.js")
R.m(931800)
module.exports=R.m(931800).exports
