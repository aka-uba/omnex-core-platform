var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/export-templates/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b33a275c._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/_next-internal_server_app_api_export-templates_[id]_route_actions_e54180a7.js")
R.m(696888)
module.exports=R.m(696888).exports
