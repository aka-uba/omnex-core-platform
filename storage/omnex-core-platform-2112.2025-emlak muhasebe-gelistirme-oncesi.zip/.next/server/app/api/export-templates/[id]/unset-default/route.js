var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/export-templates/[id]/unset-default/route.js")
R.c("server/chunks/[root-of-the-server]__c26acceb._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/ce889_server_app_api_export-templates_[id]_unset-default_route_actions_1634cad6.js")
R.m(932080)
module.exports=R.m(932080).exports
