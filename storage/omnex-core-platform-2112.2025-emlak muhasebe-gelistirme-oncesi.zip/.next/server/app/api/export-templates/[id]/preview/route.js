var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/export-templates/[id]/preview/route.js")
R.c("server/chunks/[root-of-the-server]__f7202a17._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/ce889_server_app_api_export-templates_[id]_preview_route_actions_76c3929a.js")
R.m(329037)
module.exports=R.m(329037).exports
