var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/export-templates/seed/route.js")
R.c("server/chunks/[root-of-the-server]__20abc632._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_41864256.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_export-templates_seed_route_actions_b7993478.js")
R.m(464992)
module.exports=R.m(464992).exports
