var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check-slug/route.js")
R.c("server/chunks/[root-of-the-server]__039397dd._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_core-client_fb52f6f0._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_check-slug_route_actions_0478a0e7.js")
R.m(673987)
module.exports=R.m(673987).exports
