var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__e0f09038._.js")
R.c("server/chunks/_666938f3._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/node_modules_next_ff5706e1._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_5aa6c6ca.js")
R.m(683932)
module.exports=R.m(683932).exports
