var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounting/subscriptions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__397ce386._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/ce889_server_app_api_accounting_subscriptions_[id]_route_actions_4ed25711.js")
R.m(356587)
module.exports=R.m(356587).exports
