var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounting/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__8b21fba0._.js")
R.c("server/chunks/node_modules_next_24785c19._.js")
R.c("server/chunks/node_modules__prisma_tenant-client_262a76f6._.js")
R.c("server/chunks/[root-of-the-server]__ad118520._.js")
R.c("server/chunks/_next-internal_server_app_api_accounting_analytics_route_actions_8353d26b.js")
R.m(959957)
module.exports=R.m(959957).exports
